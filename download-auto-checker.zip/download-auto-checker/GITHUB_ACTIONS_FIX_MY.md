# Build APK မပေါ်ရင် ဒီအတိုင်းလုပ်ပါ

## အကြောင်းရင်း
ဖုန်းက GitHub Upload လုပ်ရင် **`.github` folder** (အစကွက်စက်) မတင်မိတတ်ပါ။  
ဒါကြောင့် **Actions → Build APK** မပေါ်ပါ။

## ဖြေရှင်းနည်း — GitHub ဝက်ဘ်မှာ workflow ကို ကိုယ်တိုင် ဖန်တီး

### ၁) Repo ဖွင့်ပါ
သင့် `download-auto-checker` repository ဝင်ပါ။

### ၂) ဖိုင်အသစ် ဖန်တီး
1. **Add file** → **Create new file**
2. File name ကို အောက်ကအတိုင်း **တိတိကျကျ** ရိုက်ပါ  

```
.github/workflows/build-apk.yml
```

(အစမှာ ` .github/` ပါရမယ်)

### ၃) အောက်က စာသား အကုန် ကူးထည့်ပါ

```yaml
name: Build APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: android

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Grant execute permission for gradlew
        run: chmod +x gradlew

      - name: Build Debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: download-checker-apk
          path: android/app/build/outputs/apk/debug/*.apk
          if-no-files-found: error
```

### ၄) Commit
**Commit new file** နှိပ်ပါ။

### ၅) Actions ဖွင့် (ပထမဆုံးအကြိမ်)
1. အပေါ်က **Actions** tab
2. “I understand my workflows, go ahead and enable them” ဆိုရင် ဖွင့်ပါ
3. ဘယ်ဘက် **Build APK** ပေါ်လာမယ်
4. **Run workflow** → branch `main` → **Run workflow**

### ၆) APK ဆွဲ
1. စိမ်းအောင် စောင့် (၅–၁၅ မိနစ်)
2. Run ကို နှိပ်
3. အောက် **Artifacts** → **download-checker-apk**
4. Download → `.apk` install

---

## android folder မပါရင်
Workflow ပေါ်လည်း build **fail** ဖြစ်မယ်။

Repo root မှာ ဒီလို ရှိရမယ်:

```
android/
  app/
  gradlew
  build.gradle.kts
  settings.gradle.kts
.github/workflows/build-apk.yml
```

`android` folder မရှိရင် zip ထဲက `android` တစ်ခုလုံး ပြန်တင်ပါ။

---

## Actions tab မတွေ့ရင်
Repo → **Settings** → **Actions** → **General**  
→ **Allow all actions** → Save
